package com.ashenlegacy.game

import kotlin.math.sqrt

class ExperienceOrb {
    var active = false
    var x = 0f
    var y = 0f
    var radius = 0f
    var value = 0
    var age = 0f

    fun spawn(x: Float, y: Float, radius: Float, value: Int) {
        this.active = true
        this.x = x
        this.y = y
        this.radius = radius
        this.value = value
        this.age = 0f
    }

    /** Орб притягивается к игроку, когда тот ближе [magnetRadius]. */
    fun update(dt: Float, targetX: Float, targetY: Float, magnetRadius: Float, pullSpeed: Float) {
        age += dt
        val dx = targetX - x
        val dy = targetY - y
        val dist = sqrt(dx * dx + dy * dy)
        if (dist < magnetRadius && dist > 0.001f) {
            // чем ближе — тем быстрее
            val k = 1f + (1f - dist / magnetRadius)
            x += dx / dist * pullSpeed * k * dt
            y += dy / dist * pullSpeed * k * dt
        }
    }
}
