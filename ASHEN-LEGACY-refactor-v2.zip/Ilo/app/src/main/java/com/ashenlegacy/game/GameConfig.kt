package com.ashenlegacy.game

/** Все числа игры в одном месте. Размеры и скорости указаны в dp (dp/сек), движок умножает их на density. */
object GameConfig {
    // Игровой цикл
    const val FIXED_STEP = 1f / 60f
    const val MAX_FRAME_TIME = 0.1f      // длинный кадр (после паузы/лага) обрезается
    const val MAX_STEPS_PER_FRAME = 5

    // Лимиты (размеры пулов)
    const val MAX_ENEMIES = 120
    const val MAX_PROJECTILES = 100
    const val MAX_ORBS = 150

    // Игрок
    const val PLAYER_RADIUS = 14f
    const val PLAYER_SPEED = 120f
    const val PLAYER_MAX_HP = 100f
    const val PLAYER_INVULN_TIME = 0.8f  // защита после получения урона, сек
    const val PLAYER_DAMAGE = 10f
    const val PLAYER_FIRE_INTERVAL = 0.55f
    const val PLAYER_MIN_FIRE_INTERVAL = 0.15f
    const val PLAYER_MAGNET_RADIUS = 90f

    // Снаряды
    const val PROJECTILE_RADIUS = 4f
    const val PROJECTILE_SPEED = 320f
    const val PROJECTILE_LIFETIME = 1.4f

    // Опыт
    const val ORB_RADIUS = 5f
    const val ORB_PULL_SPEED = 240f
    const val XP_BASE = 10f
    const val XP_GROWTH = 1.25f

    // Спавн врагов
    const val SPAWN_INTERVAL_START = 1.2f
    const val SPAWN_INTERVAL_MIN = 0.25f
    const val SPAWN_INTERVAL_DECAY_PER_SEC = 0.01f
}
